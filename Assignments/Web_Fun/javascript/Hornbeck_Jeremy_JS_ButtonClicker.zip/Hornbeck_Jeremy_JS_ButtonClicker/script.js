function hide(element) {
    element.remove();
}

function logOff(element) {
    element.innerText = "Logff"
}