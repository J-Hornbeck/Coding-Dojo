console.log("page loaded...");

function play() {
    .play()
}

function pause() {
    .pause()
}